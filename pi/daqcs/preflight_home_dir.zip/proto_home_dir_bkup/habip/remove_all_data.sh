#!/usr/bin/env bash

rm -rf photo_video_sw/logs/*.log photo_video_sw/logs/*.csv photo_video_sw/photos/*.jpeg photo_video_sw/videos/*.h264 sensors_sw/data_i2c/*.csv sensors_sw/data_w1/*.csv sensors_sw/logs_i2c/*.log sensors_sw/logs_w1/*.log uart_monitor/logs_uart/*.log
